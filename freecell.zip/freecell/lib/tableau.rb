require_relative 'deck'

class Tableau

  def initialize

  end

  def pop

  end

  def peek

  end

  def empty?

  end

  def add(card)

  end

  def force_push(card)

  end

  def [](i)
    # only used for display purposes
    stack[i]
  end

  def length
    # only used for display purposes
    stack.length
  end

  private

end
